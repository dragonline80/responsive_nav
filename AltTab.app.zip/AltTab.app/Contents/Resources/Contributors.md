# Contributors

They helped [develop the app](https://github.com/lwouis/alt-tab-macos/graphs/contributors):

* [adamnemecek](https://github.com/adamnemecek)
* [AfzalivE](https://github.com/AfzalivE)
* [akx](https://github.com/akx)
* [Allsochen](https://github.com/Allsochen)
* [ayroblu](https://github.com/ayroblu)
* [Calinou](https://github.com/Calinou)
* [damonpam](https://github.com/damonpam)
* [decodism](https://github.com/decodism)
* [delaneyb](https://github.com/delaneyb)
* [gingerr](https://github.com/gingerr)
* [GrzegorzKazana](https://github.com/GrzegorzKazana)
* [hughlilly](https://github.com/hughlilly)
* [karbassi](https://github.com/karbassi)
* [L1cardo](https://github.com/L1cardo)
* [lwouis](https://github.com/lwouis)
* [metacodes](https://github.com/metacodes)
* [mnin](https://github.com/mnin)
* [MrPaschenko](https://github.com/MrPaschenko)
* [nella17](https://github.com/nella17)
* [notlmn](https://github.com/notlmn)
* [phungtuanhoang1996](https://github.com/phungtuanhoang1996)
* [rbnis](https://github.com/rbnis)
* [Rjevski](https://github.com/Rjevski)
* [samdenty](https://github.com/samdenty)
* [ShlomoCode](https://github.com/ShlomoCode)
* [skolj](https://github.com/skolj)
* [stopdesign](https://github.com/stopdesign)
* [xanathar](https://github.com/xanathar)
* [zacharee](https://github.com/zacharee)

They helped [localize the app](https://poeditor.com/join/project/8AOEZ0eAZE):

* 73
* Aamirsuleman
* Aarni Koskela
* Abdulelah
* Abdur-Rahman Bilal
* Aden Aziz
* Admin
* Aindriú Mac Giolla Eoin
* Ajaykumarmkaju
* Aku
* Albert Abdilim
* Aleksander Bang-Larsen
* Alex
* Alexander Kilian
* Alexey Eremeev
* Ali
* Ali Gokmen
* Ali. tas103
* Allen Guan
* Alonso Chen
* Ameng
* Anders
* Andreas Wagner
* Andrej Koman
* Andrew Vader
* antoon334
* Anurag Roy
* anushree b
* Arman
* Artem Stankov
* Arthur
* Ash
* blanorama
* bluefirex
* bovirus
* Bruno Norrå
* BV Joshi
* caduellery
* Caner İlhan
* catcore
* Christian Keilmann
* Chun Fei Lung
* codecantata
* codingalone
* Cong Tri
* Dan
* Dan84
* Darius Rosendahl
* Darko
* David R
* Denis
* Dékány Martin
* dibas-np
* Didier Deschrijver
* Dzhuneyt
* edu_sombra
* EDUARDO
* Eimantas
* Eliezer Shpigelman
* EP45
* Eric WANTZ
* Ersagun Kuruca
* EUKA
* Eukarya
* Eyelly wu
* fil
* Filipe
* Frangarciasalomon
* Frank
* Friendship1
* Fukuda
* Ganesh Sawant
* Gezimos
* Giacomo Volpi
* Giang
* Github
* Gkostov
* Grzegorz Kazana
* Guillaume
* Gumpanath Puttarassu
* hann-solo
* Haoshuai Xu
* Hao豪
* Hjörtur Hjartarson
* Hokuto Kato
* Huandngoc
* Huynh Sang
* Ialiendeg
* Ida Bomholt Dyrholm Jacobsen
* Igor Aradski
* igorpocta
* Indexerrowaty
* Inês Almeida
* isametry
* Ismatulla
* Isthereanybody
* Jaeyong Sung
* Jakob
* Jakob Licina
* Jakub Bartušek
* Jesus Angel Villafuerte
* jiho4
* Jisan
* Joao Vitor Casarin
* Jord Nijhuis
* Jui Yuan Liu
* Jules Beckers
* Julian Nowaczyk
* Julio
* justcontributor
* Kagurazaka Tsuki
* kal
* kant
* Kawarimidoll+git
* kazuki sakamoto
* Kevinsevinche
* KillianG
* Kinyagulovrr
* Klara
* Kostiantyn Ko
* Kristófer Fannar Björnsson
* Kushnee5
* Kuuchi
* L
* Lakshman Kolappan
* Lasse Mattila
* Lcwhhh
* Lester
* Logan Boissy
* Loic. peron
* Loïc 
* LostInCompilation
* Lumaxis
* lwouis
* M
* Malo
* Maplevantablack
* Marc Pla
* Marcus Billman
* Marekscholle
* Marko McLion
* Martin Mitka
* Martin. mitka
* Masayoshi Motojima
* Masih
* Matheus
* Max
* Maximilian Falk
* MaximilianFreitag
* Mehmet Ali Ertorer
* Meriç Bağlayan
* Michael
* Milos M
* Mohammad Al Zouabi
* mohma
* Mr. axel. bock
* mrtbts
* MuDraconis
* Muzhenstudent
* Mwolfinspace
* Naseeb Naushad
* Nathancodes
* Navekar Vishal
* Nikola Rajić
* Nils Fahldieck
* Nilton Souza
* Nmolham
* Nuriddin Islamov
* Ori
* Paul Pichaureau
* Paul Przybyszewski
* Paul. pichaureau
* Pehovorka
* Petar Shomov
* Peterkim0620
* Petr Kolář
* Piotr Budny
* Quentin. douarre
* Rami Elsawy
* Raphaël
* Rasmus
* Raymonf
* raz
* Razvan
* rbnis
* rei fujise
* Roccobot
* Roccobot
* Rodrigo Schneider
* Ron Nuss
* rPaasch
* Ryan Nardi
* sa-ha
* Sai Khant Zay Lynn Yaung
* Saransh
* sawtooth
* Sebastian
* Selcuk Dursun
* Sergey
* Seyedparsa Mirtaheri
* Shameem Reza
* SheNeVmerla
* Shivam Bansal
* shlomo
* Sippawit Thammawiset
* Sjur Moshagen
* Sjur.n. moshagen
* Stan Smits
* star-affinity
* Stefan
* Stefan Lange
* Svetoslav Stefanov
* Thebennue
* Thomas Wölk
* Thorsten
* Thorsten
* Tomoa Nozawa
* Trevor
* Tsilimpotis Dimitrios
* Umutakkaya1996
* User23483
* Vadym
* Vijayant Saini
* Vincent Orback
* Vlad
* Webmaster
* Wesley Matos
* Whatsmine-HaoshuaiXu
* Wilhelm Wolfgang Gärtner
* Yongsung Yoon
* Yorben
* Yossi Zahn
* ysaito
* Yukai
* yumechan
* Yusuf Caliskan
* Zamaialexander
* Zuhaib Syed
* Τσιλιμπότης Δημ.
* Андрій Кирбаба
* Ивайло
* Пустой
* 林清
* 橙梓
